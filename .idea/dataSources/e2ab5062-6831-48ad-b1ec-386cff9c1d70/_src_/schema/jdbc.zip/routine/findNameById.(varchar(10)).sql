CREATE PROCEDURE findNameById(IN sid VARCHAR(10), OUT name VARCHAR(10))
  begin 
SELECT stu_name into Name from student where stu_id=sid; 
end;
