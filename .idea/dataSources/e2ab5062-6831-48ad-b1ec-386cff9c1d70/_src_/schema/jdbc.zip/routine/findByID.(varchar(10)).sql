CREATE PROCEDURE findByID(IN sid VARCHAR(10))
  begin
   SELECT * from student where stu_id=sid;
end;
